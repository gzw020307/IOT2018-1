#include "stdafx.h"

int main()
{
	menu2();
	return 0;
}


