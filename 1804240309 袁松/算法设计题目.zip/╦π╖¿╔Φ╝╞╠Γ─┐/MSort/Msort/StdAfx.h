#pragma once
#include<iostream>
using namespace std;
#define MAXSIZE 100
typedef struct {
	int lenth;
	int *R;
}SqList;

void InitSqLIst(SqList& L, unsigned int lenth);
void CreateSqList(SqList& L);
void DestorySqList(SqList& L);
void PrintSqList(SqList L);
void Merge(int*& R, int low, int high);
void Msort(int*& R, int low, int high, int level, int& count);
void menu3();