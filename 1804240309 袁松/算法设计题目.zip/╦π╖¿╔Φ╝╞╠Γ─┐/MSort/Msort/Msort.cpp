#include "stdafx.h"

int main()
{
	menu3();
	return 0;
}


