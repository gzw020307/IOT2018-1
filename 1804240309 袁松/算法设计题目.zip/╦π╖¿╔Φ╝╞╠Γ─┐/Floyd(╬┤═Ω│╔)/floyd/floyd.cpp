#include "stdafx.h"

int main() {
	Mgraph g;
	path p;
	dist d;
	init(&g);
	Floyd(g,p,d);
	cout<<"������Ҫ��ѯ�Ķ�����"<<endl;
	int x,y;
	cin>>x>>y;
	for(int i = 0; i < g.n; i++) {
		for(int k = 0; k < g.n; k++) {
			cout<<d[i][k]<<" ";
		}
		cout<<endl;
	}
	for(int m = 0; m < g.n; m++) {
		for(int j = 0; j < g.n; j++) {
			cout<<p[i][j]<<"   ";
		}
		cout<<endl;
	}
	cout<<x<<"--->";
	while(p[x][y] != -1 && p[x][y] != x){
		cout<<p[x][y]<<"--->";
		x = p[x][y];
	}
	cout<<y<<endl;
	return 0;
}