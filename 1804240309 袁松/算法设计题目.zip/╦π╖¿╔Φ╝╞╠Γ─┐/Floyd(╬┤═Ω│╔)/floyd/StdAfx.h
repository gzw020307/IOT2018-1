#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string.h>
#define M 20
#define FINITY 10000
using namespace std;
typedef char vertextype;
typedef int edgetype;
typedef int dist[M][M];  	//����
typedef int path[M][M]; 	//·��
typedef struct {
	vertextype vex[M];
	edgetype edges[M][M];
	int n,e;   //�������ͱ���
} Mgraph;


void init(Mgraph *g);
void  Floyd(Mgraph g,path p,dist d);
