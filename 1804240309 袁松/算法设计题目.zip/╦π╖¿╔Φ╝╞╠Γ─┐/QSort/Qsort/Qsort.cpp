#include "stdafx.h"

int main()
{
	menu1();
	return 0;
}
