#include "Huffmantree.h"

void msg(void)
{
    cout << "-------------------------Menu-------------------------\n"
         << "*       1.Create BiTreeA (inOrder)                   *\n"
         << "*       2.inOrderTraversal the BiTreeA(recurtion)    *\n"
         << "*       3.inOrderTraversal the BiTreeA(non-recurtion)*\n"
         << "*       4.DestoryTreeA                               *\n"
         << "*       5.Create BiThrTreeB(Need TreeA)              *\n"
         << "*       6.inOrderTraversal the BiThrTreeB            *\n"
         << "*       7.DestroyTreeB                               *\n"
         << "*       8.Create HuffmanTreeC                        *\n"
         << "*       0.Exit.                                      *\n"
         << "-------------------------Menu-------------------------\n"
         << "Enter the function you want to choose(0-9):";
} // msg

void inOrderTraversalBiTreeR(BiTNode *T)
{
    // 中序遍历链二叉树（递归法）
    if (T != NULL)
    {
        inOrderTraversalBiTreeR(T->Lchild);
        cout << setw(4) << T->data;
        inOrderTraversalBiTreeR(T->Rchild);
    }
} //inOrderTraversalBiTreeR

void inOrderTraversalBiTreeNR(BiTNode *T)
{
    BiTNode *p = T;
    stack<BiTNode *> s;
    while (!s.empty() || p)
    {
        //代码段(i)一直遍历到左子树最下边，边遍历边保存根节点到栈中
        while (p)
        {
            s.push(p);
            p = p->Lchild;
        }
        //代码段(ii)当p为空时，说明已经到达左子树最下边，这时需要出栈了
        if (!s.empty())
        {
            p = s.top();
            s.pop();
            cout << setw(4) << p->data;
            //进入右子树，开始新的一轮左子树遍历(这是递归的自我实现)
            p = p->Rchild;
        }
    }
} // inOrderTraversalBiTreeNR

bool CreateBiTree(BiTree &T)
{
    // 按先序序列输入二叉树中的节点值,空格代表空字符
    ElemType ch;
    cout << "Enter a elem('#' means NULL): ";
    cin >> ch;
    if (ch == '#')
        T = NULL;
    else
    {
        T = new (BiTNode);
        if (!T)
            exit(OVERFLOW); // 申请空间失败
        T->data = ch;
        CreateBiTree(T->Lchild); // 递归建立左子树
        CreateBiTree(T->Rchild); // 递归建立右子树
    }                            // else
    return OK;
} // CreateBiTree

// ---------------销毁二叉树↓---------------
// 采用后序遍历法

void TreeNodeDestroy(BiTree &T)
{
    if (T == NULL)
        return;
    delete T;
} // TreeNodeDestroy

void TreeDestroy(BiTree &T)
{
    if (T == NULL)
        return;
    TreeDestroy(T->Lchild);
    TreeDestroy(T->Rchild);
    TreeNodeDestroy(T);
} // TreeDestroy

// ---------------销毁二叉树↑---------------

// ---------------线索二叉树↓---------------
void inOrderThreading(BiTree T, BiTNode *&Prev) //出现左树为空或者右树为空，就需要线索化
{
    if (T == NULL)
        return;
    inOrderThreading(T->Lchild, Prev);
    //T在这出现的顺序就是中序  上一层结构设置的栈帧，用引用
    if (T->Lchild == NULL)
    {
        T->Lchild = Prev;
        T->Ltag = 1;
    }
    if (Prev && Prev->Rchild == NULL)
    {
        Prev->Rchild = T;
        Prev->Rtag = 1;
    }
    Prev = T;
    inOrderThreading(T->Rchild, Prev);
}

void inOrderTraversalThrTree(BiTree T)
{
    BiTNode *p = T;
    while (p)
    {
        while (p->Ltag == 0)
            p = p->Lchild;
        cout << setw(4) << p->data;
        if (p->Rtag == 0)
            p = p->Rchild;
        else
        {
            while (p->Rtag == 1)
            {
                p = p->Rchild;
                cout << setw(4) << p->data;
            }
            p = p->Rchild;
        }
    }
    cout << endl;
}
// ---------------线索二叉树↑---------------
