#include "Function.h"

int main(int argc, char const *argv[])
{
    int choose;
    BiTree T;

    do
    {
        msg();
        cin >> choose;
        switch (choose)
        {
        case 1:
            CreateBiTree(T);
            cout << "\nCreate Finished." << endl;
            break;

        case 2:
            inOrderTraversalBiTreeR(T);
            cout << "\nTraversal Finished.\n"
                 << endl;
            break;

        case 3:
            inOrderTraversalBiTreeNR(T);
            cout << "\nTraversal Finished.\n"
                 << endl;
            break;

        case 4:
            TreeDestroy(T);
            cout << "\nDestroy Finished.\n"
                 << endl;
            break;

        case 5:
            inOrderThreading(T, Prev);
            cout << "\nCreatre Finished.\n"
                 << endl;
            break;

        case 6:
            inOrderTraversalThrTree(T);
            cout << "\nTraversal Finished.\n"
                 << endl;
            break;

        case 7:
            TreeDestroy(T);
            cout << "\nDestroy Finished.\n"
                 << endl;
            break;

        case 8:
            createHuffmantree();
            cout << "\nCreate Finished.\n"
                 << endl;
            break;

        case 0:
            exit(1);
        }

    } while (choose != 0);

    return 0;
} // main
