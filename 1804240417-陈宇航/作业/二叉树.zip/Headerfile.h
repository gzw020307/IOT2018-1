// --------------------ECORE--------------------
// 程序目的：完成有关于树的各项操作
// --------------------ECORE--------------------
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <limits.h>
#include <iomanip>
#include <stack>
#include <iostream>

using namespace std;

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASIBLE -1
#define OVERFLOW -2

// --------------------ECORE--------------------
#define ElemType char
#define MAXSIZE 100      // 暂定二叉树中结点个数的最大值为100
#define MAXSTACKSIZE 100 // 栈的最大值
#define MAXDATA 1000
// --------------------ECORE--------------------

// --------------------BiTree--------------------
typedef struct BiTNode
{
    ElemType data;
    int Ltag = 0;
    int Rtag = 0; // 左右孩子标志
    struct BiTNode *Lchild;
    struct BiTNode *Rchild; // 左右孩子指针
    struct BiTNode *parent; // 双亲指针
} BiTNode, *BiTree;         // 二叉树的链式存储结构
// --------------------BiTree--------------------

// -------------------EStack-------------------
typedef struct Stack
{
    ElemType *base; // 存储空间基址
    int top;        // 栈顶指针
    int stacksize;  // 允许的最大存储空间以元素为单位
} Stack, *Pstack;
// -------------------EStack-------------------

// --------------------Heap--------------------
typedef struct HNode *Heap; // 堆的类型定义
struct HNode
{
    int *data;    // 存储元素的数组
    int Size;     // 堆中当前元素个数
    int Capacity; // 堆的最大容量
};
typedef Heap MaxHeap; // 最大堆
typedef Heap MinHeap; // 最小堆
// --------------------Heap--------------------

// ------------------Huffmantree------------------
typedef struct
{
    unsigned int weight;
    unsigned int parent, lchild, rchild;
} htnode, *huffmantree; // 赫夫曼树的结构类型

typedef char **huffmancode;
// ------------------Huffmantree------------------

int i, j;
BiTNode *Prev = NULL;