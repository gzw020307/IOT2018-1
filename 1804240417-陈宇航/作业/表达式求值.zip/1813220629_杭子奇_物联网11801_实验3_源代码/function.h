# include "headerflie.h"

void msg(){ // �˵���
    cout << "------------------Menu------------------\n"
		<< "*      1. ��ʼ������������ʽA\n"
		<< "*      2. ��ʼ������������ʽB\n"
		<< "*      3. ����ʽA��B������ɶ���ʽC\n"
		<< "*      4. ��ʾ����ʽC\n"
		<< "*      5. ���ٶ���ʽC\n"
		<< "*      0. �˳�\n"
		<< "----------------------------------------\n"
		<< "������ѡ���ܵı��(0-5): ";
}

void InitPList(PolyList &L){ // ��ʼ������
    L = new PNode;
    if (!L) exit(1);
    L->coe = 0;
    L->exp = 0;
    L->next = NULL;
} // InitPoly

bool PListInsert(PolyList &L, int pos, float Tcoe, int Texp){ // ������
    PolyList s;
    p = L; j = 0;
    while (p && j < pos-1){
        p = p->next;
        ++j;
    } // while
    if (!p || j > pos-1) return FALSE;
    s = new PNode;
    s->coe = Tcoe;
    s->exp = Texp;
    s->next = p->next;
    p->next = s;
    p = s;
    return TURE;
} // PListInsert

void CreateList(PolyList &L){ // ��������
    InitPList(L);
    int Texp;
    float Tcoe;
    i = 1;
	
    while (Tcoe!= 0){
        printf("�������%d���ϵ��: ", i);
        cin >> Tcoe;
        printf("�������%d���ָ��: ", i);
        cin >> Texp;
        if (Tcoe != 0) PListInsert( L, i, Tcoe, Texp);
        ++i;
    }
} // CreateList

void DestroyList(PolyList &L){ // ��������
    while (L){
        p = L;
        L = L->next;
        delete p;
    } //while
    L = NULL;
} // DestroyList

void ListPrint(PolyList L){ // �������
    cout <<"\n The List:" << endl;
    L = L->next;
    while (L->next != NULL){
        printf("%.2f x ^ %d", L->coe, L->exp);
        printf(" + ");
        L = L->next;
    } // while
    printf("%.2f x ^ %d", L->coe, L->exp);
    printf("\n");
} // ListPrint

  /*	�ϰ�
  
	bool PolyListAdd(PolyList &A, PolyList &B){
	if ((A->next = NULL) || (B->next = NULL))  {
	cout << "���������´�������ʽA��B" << endl;
	return FALSE;
	}
	A = A->next;
	B = B->next;
	
	  // if (A->exp < B->exp){
	  //     C = A;
	  //     A = A->next;
	  // }
	  // else if (A->exp = B->exp){
	  //     A->coe += B->coe;
	  //     C = A;
	  //     A = A->next;
	  // }
	  
		// else{
		//     C = B;
		//     B = B->next;
		// }
		
		  while(A != NULL && B != NULL){
		  if (A->exp < B->exp){
		  C->next = A;
		  C = A;
		  A = A->next;
		  }
		  else if (A->exp == B->exp){
		  A->coe += B->coe;
		  if (A->coe == 0) {
		  A = A->next;
		  B = B->next;
		  continue;
		  }
		  else {
		  C->next = A;
		  C = A;
		  A = A->next;
		  B = B->next;
		  }
		  }
		  
			else{
			C->next = B;
			C = B;
			B = B->next;
			}
			}
			
			  if (A->next != NULL) C->next = A;
			  if (B->next != NULL) C->next = B;
			  else C->next = NULL;
			  
				delete(A);
				delete(B);
				return TURE;
				}
*/
PolyList AddList(PolyList L1, PolyList L2){ // ����ʽ�������
	
	PolyList L3;
	L1 = L1->next;
	L2 = L2->next;
	L3 = new PNode;
	q = L3;
	
	while (L1 != NULL && L2 != NULL){ // ��L1��L2����Ϊ��ʱ
		if (L1->exp < L2->exp){
			p = new PNode;
			p->coe = L1->coe;
			p->exp = L1->exp;
			q->next = p;
			q = p;
			L1 = L1->next;
		}
		
		else if (L1->exp == L2->exp){
			p = new PNode;
			p->coe = L1->coe + L2->coe;
			p->exp = L1->exp;
			
			if (p->coe == 0) delete(p);
			
            else{
				q->next = p;
				q = p;
			}
			
			L1 = L1->next;
			L2 = L2->next;	
		}
		
		else{
			p = new PNode;
			
            p->coe = L2->coe;
			p->exp = L2->exp;
			q->next = p;
			q = p;
			
			L2 = L2->next;
		}
	} // while
	
	if (L1 != NULL) q->next = L1;
	
	else if (L2 != NULL)    q->next = L2;
	
	else    q->next = NULL;
	
	return L3;
	
} // AddList