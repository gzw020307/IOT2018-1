# include "function.h"

int main(void){
    int choose;

    InitPList(A);
    InitPList(B);
    InitPList(C);

    do{
        msg();
        cin >> choose;

        switch (choose)
        {
        case 1:
            CreateList(A);
            ListPrint(A);
            break;
        
        case 2:
            CreateList(B);
            ListPrint(B);
            break;
        
        case 3:
            C = AddList(A, B);
            ListPrint(C);
            break;

        case 4:
            ListPrint(C);
            break;
        
        case 5:
            DestroyList(C);
            break;

        case 0:
            exit(1);
        }


    } while( choose != 0);


    return 0;
}