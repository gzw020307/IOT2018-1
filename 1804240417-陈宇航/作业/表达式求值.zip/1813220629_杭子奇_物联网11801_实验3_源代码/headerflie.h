# include <stdio.h>
# include <stdlib.h>
# include <iostream>
# include <string.h>

# define TURE 1
# define FALSE 0

using namespace std;

typedef struct PNode{
    float coe;
    int exp;
    struct PNode *next;
} PNode, *PolyList;

PNode *p, *q, *s;
int i, j;
PolyList A, B, C;
