# include <STDIO.H>
# include <STDLIB.H>
# include <STRING.H>
# include <IOSTREAM>

using namespace std;

# define ElemType int
# define FALSE 0
# define TRUE 1
# define ERROR 0

typedef struct LNode{
	ElemType data;
	struct LNode *next;
} LNode, *SLink;	//���쵥����

void InitList();
void DestroyList();
bool GetElem();
bool ListInsert();
bool ListDelete();
void CreateList_L();
void exchange_L();
void purge_L();
void MergeList_L();
SLink connect();
void menu();
void msg();