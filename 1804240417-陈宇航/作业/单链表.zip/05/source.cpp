# include "function.h"


/*
Ҫ�����Ա�����ʽ�洢�ṹ�µĻ���������
�ڴ˻�����ʵ��ͷ�巨��β�巨�������������㷨,
ɾ���������С����ࡱԪ�ص��㷨��
*/

int main(){
	int choose;
	int pos;
	ElemType e;

	InitList(H);
		do
		{
			msg();
			cin >> choose;

			switch (choose)
			{
			case 1:
				InitList(H);
				cout << "Please enter the list's maxsize:" << endl;
				cin >> pos;

				for (i = 1; i <= pos; i++){
					printf("Enter a elem(%d/%d):", i, pos);
					cin >> e;
					ListInsert(H, 1, e);
				}

				cout << "Finished." << endl;
				ListPrint(H);

				break;

			case 2:
				InitList(H);
				cout << "Please enter the list's maxsize:" << endl;
				cin >> pos;

				for (i = 1; i <= pos; i++){
					printf("Enter a elem(%d/%d):", i, pos);
					cin >> e;
					ListInsert(H, i, e);
				}

				cout << "Finished." << endl;
				ListPrint(H);


				break;

			case 3:
				cout << "Please enter the Location you want to search:" << endl;
				cin >> pos;
				printf("The elem at the location is: %d\n",GetElem(H, pos));

				break;

			case 4:
				cout << "Please enter the elem you want to insert:" << endl;
				cin >> e;
				cout << "Please enter the location you want to insert:" << endl;
				cin >> pos;
				ListInsert(H, pos, e);
				cout << "Finished" << endl;
				ListPrint(H);
				
				break;

			case 5:
				cout << "Please enter the elem's location:" << endl;
				cin >> pos;
				ListDelete(H, pos);
				cout << "Finished" << endl;
				ListPrint(H);

				break;

			case 6:
				ListPrint(H);

				break;

			case 7:
				purge_L(H);
				cout << "Finished" << endl;
				ListPrint(H);

				break;

			case 9:
				DestroyList(H);
				cout << "Finished" << endl;

				break;

			case 0:
				exit(1);
			}


		} while (choose != 0);

	return 0;
}