# include <stdio.h>
# include <stdlib.h>
# include <iostream>

# define TRUE 1
# define FALSE 0
# define OK 1
# define ERROR 0
# define OVERFLOW -1

//----------------------------------------
# define MAXLISTSIZE 10000
# define ElemType int
//----------------------------------------

using namespace std;

typedef struct Stack{
    ElemType *base; // 存储空间基址
    int top;        // 栈顶指针
    int stacksize;  // 允许的最大存储空间以元素为单位
} Stack, *Pstack;

int i, j;
ElemType *p, *q;