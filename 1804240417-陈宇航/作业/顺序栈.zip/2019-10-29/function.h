# include "headerfile.h"

void msg(void){
    cout<< "-------------------------Menu-------------------------\n"
        << "*       1.(Initialize)Create a Stack                 *\n"
        << "*       2.Push elem                                  *\n"
        << "*       3.Pop elem                                   *\n"
        << "*       4.Clear the Stack                            *\n"
        << "*       5.Print the Stack                            *\n"
        << "*       9.Destroy the Stack                          *\n"
        << "*       0.Exit.                                      *\n"
        << "-------------------------Menu-------------------------\n"
        << "Enter the function you want to choose(0-9):";
}

void InitStack(Stack &S, int maxsize){
    // 构造一个最大存储容量为maxsize的空栈S
    if (maxsize == 0)   maxsize = MAXLISTSIZE;

    S.base = new ElemType[maxsize];

    if (!S.base) exit(OVERFLOW);    // 内存空间不足或其他原因导致存储空间分配失败
    S.stacksize = maxsize;
    S.top = 0;       // 空栈中元素个数为0

}

void DestroyStack(Stack &S){
    // 销毁栈S, 释放其所占用的内存空间
    delete [] S.base;
    S.top = 0;
    S.stacksize = 0;
}

void ClearStack(Stack &S){
    // 清空栈S内的元素, 但并不将其销毁
    while (S.top) {
        S.base[S.top] = NULL;
        --S.top;
    }
    S.base[0] = NULL;
}

bool StackEmpty(Stack &S){
    // 若栈S为空栈, 则返回 TRUE, 否则返回 FALSE
    if (S.top == 0) return TRUE;
    else return FALSE;
}

int StackLength(Stack &S){
    return S.top;
    // 返回栈S的元素个数, 即栈的长度
}

bool GetTop(Stack S, ElemType &e){
    // 若栈不为空, 则用e返回S 的栈顶元素, 并返回TRUE, 否则返回FALSE
    if (S.top == 0) return FALSE;
    e = *(S.base + S.top -1);   // 返回非空栈中栈顶元素
    return OK;
}

bool Push(Stack &S, ElemType e){
    // 若栈的存储空间不满, 则插入元素e为新的栈顶元素, 并返回TRUE
    // 否则返回FALSE
    if (S.top == S.stacksize)   // 栈满，无法继续插入
        return FALSE;
    *(S.base +S.top) = e;       // 插入新的元素
    ++S.top;                    // 栈顶指针后移
    return OK;
}

bool Pop(Stack &S, ElemType &e){
    // 若栈不空, 则删除S的栈顶元素, 用e返回其值, 并返回TRUE, 否则返回FALSE
    if (S.top == 0) return FALSE;
    e = *(S.base +S.top-1);     // 返回非空栈中栈顶元素
    --S.top;                    // 栈顶指针前移
    return OK;
}

void StackTraverse(Stack S, void (*visit(ElemType))){
    // 依次对S的每个元素调用函数visit(), 一旦visit()失败, 则操作失败

}

void StackPrint(Stack S){
    // 输出栈
    int t, n;

    cout<< "\n-----------------------------------\n" 
        << "\nThe stack's size(" 
        << S.top << "/"<< S.stacksize<< "): "
        <<"\n\nThe Stack:\n\nTOP ->" << " ";
    
    for (t = S.top-1, n = 0; t >= 0; --t, ++n){
        ((n!=0) && (n%10) == 0)?(printf("\n")):(NULL);
        (t == 0)?(cout << S.base[t]):(cout << S.base[t] << " -> ");
    }

    cout<< "\n-----------------------------------\n" << endl;
}