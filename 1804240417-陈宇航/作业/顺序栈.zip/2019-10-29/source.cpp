# include "function.h"


int main(void){
    char ch;
    ElemType e;
    int pos;
    int choose;
    Stack S;

    do{
        msg();
        cin >> choose;
        switch(choose){
            case 1:
                cout <<"\n Enter the Stack's maxsize(<=10000): ";
                cin >> pos;
                InitStack (S, pos);
                break;

            case 2:
                printf("\nHow many elems do you want to push in?(now: %d/%d):", S.top, S.stacksize);
                cin >> j;

                if ((S.top + j) > S.stacksize){
                    cout << "Do not have enough size." << endl;
                    break;
                }

                for(i = 1; i <= j; ++i){  
                    printf("Enter a elem(%d/%d):", i, j);
                    cin >> e;
                    Push(S, e);
                }

                StackPrint(S);
                break;

            case 3:
                StackPrint(S);
                cout << "\nHow many elems do you want to pop out?: ";
                cin >> j;
                if (j < 0 || j > S.top){
                    cout <<"Error, please check the number." << endl;
                    break;
                }

                for (i = 1; i <= j; ++i)    Pop(S, e);

                StackPrint(S);

                break;

            case 4:
                ClearStack(S);
                
                cout << "Clear finished." << endl;
                break;

            case 5:
                StackPrint(S);
                break;
            
            case 9:
                DestroyStack(S);

                cout << "Destroy finished." << endl;
                break;

            case 0:
                exit(1);    
        }

    }while(choose != 0);

    return 0;
}