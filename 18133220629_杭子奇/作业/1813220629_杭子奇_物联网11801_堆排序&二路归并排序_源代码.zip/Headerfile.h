// --------------------ECORE--------------------
// #实验内容

// 已知一个长度为 15 的线性表,其关键字序列为 {19,38,12,40,41,39,54,76,35,47,80,14,9,44,19}

// 编程实现如下功能：

// 分别使用折半插入排序、冒泡排序、堆排序和2-路归并排序对这个该关键字序列排序。

// 对每种排序算法要求不仅输出最终有序序列,还有输出每趟排序后产生的关键字序列

// 计算并输出每种排序的趟数

// 分析这些算法的稳定性

// --------------------ECORE--------------------
#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASIBLE -1
#define OVERFLOW -2

// --------------------ECORE--------------------
#define ElemType int
// --------------------ECORE--------------------

ElemType *p, *q;

typedef struct SqList
{
    ElemType *elem;
    int length;
} SqList;