#include "Headerfile.h"

void msg(void)
{
    cout << "-------------------------Menu-------------------------\n"
         << "*       1.bin_Insertsort                             *\n"
         << "*       2.bubble_Sort                                *\n"
         << "*       3.heap_Sort                                  *\n"
         << "*       4.merge_Sort                                 *\n"
         << "*       5.printList                                  *\n"
         << "*       0.Exit.                                      *\n"
         << "-------------------------Menu-------------------------\n"
         << "Enter the function you want to choose(0-9):";
}
void printList(SqList L)
{
    // 显示线性表L
    int i;
    for (i = 1; i <= L.length; ++i)
        cout << setw(4) << L.elem[i];
    cout << endl;
} // ListPrint_Sq

void bin_Insertsort(SqList &L)
{
    int low, high, m, i, j, count = 0;
    for (i = 2; i <= L.length; ++i)
    {
        if (L.elem[i] < L.elem[i - 1])
        {
            L.elem[0] = L.elem[i];
            low = 1;
            high = i - 1;
            while (low <= high)
            {
                m = (low + high) / 2;
                if (L.elem[0] < L.elem[m])
                    high = m - 1;
                else
                    low = m + 1;
            } // while

            for (j = i - 1; j >= high + 1; --j)
                L.elem[j + 1] = L.elem[j];
            L.elem[low] = L.elem[0];

            count++;
            cout << "\nThe step" << setw(3) << count << ": ";
            printList(L);
        }
    }
} // bin_Insertsort

void bubble_Sort(SqList &L)
{
    int i = L.length, j, flag, count = 1;
    while (i > 1)
    {
        flag = 1;
        for (j = 1; j < i; ++j)
        {
            if (L.elem[j] > L.elem[j + 1])
            {
                swap(L.elem[j], L.elem[j + 1]);
                flag = j;
                count++;
                cout << "\nThe step" << setw(3) << count << ": ";
                printList(L);
            }
        }
        i = flag;
    }

} // bubble_Sort

// --------------------ECORE--------------------
// 堆排序
// --------------------ECORE--------------------
void max_heapify(int arr[], int start, int end)
{
    //建立父节点指标和子节点指标
    int dad = start;
    int son = dad * 2 + 1;
    while (son <= end) //若子节点指标在范围内才做比较
    {
        if (son + 1 <= end && arr[son] < arr[son + 1]) //先比较两个子节点大小，选择最大的
            son++;
        if (arr[dad] > arr[son]) //如果父节点大於子节点代表调整完毕，直接跳出函数
            return;
        else //否则交换父子内容再继续子节点和孙节点比较
        {
            swap(arr[dad], arr[son]);
            dad = son;
            son = dad * 2 + 1;
        }
    }
}

void heap_Sort(SqList &L)
{
    int count = 0;
    //初始化，i从最後一个父节点开始调整
    for (int i = L.length / 2 - 1; i >= 0; i--)
    {
        max_heapify(L.elem, i, L.length - 1);
        count++;
        cout << "\nThe step" << setw(3) << count << ": ";
        printList(L);
    }
    //先将第一个元素和已经排好的元素前一位做交换，再从新调整(刚调整的元素之前的元素)，直到排序完毕
    for (int i = L.length - 1; i > 0; i--)
    {
        swap(L.elem[0], L.elem[i]);
        max_heapify(L.elem, 0, i - 1);
        count++;
        cout << "\nThe step" << setw(3) << count << ": ";
        printList(L);
    }
}

// --------------------ECORE--------------------
// 归并排序
// --------------------ECORE--------------------
void Merge(int array[], int p, int q, int r, SqList &L)
{
    int n1 = q - p + 1;
    int n2 = r - q;
    static int count = 0;

    int *Left;
    Left = (int *)malloc(sizeof(int) * n1);
    int *Right;
    Right = (int *)malloc(sizeof(int) * n2);

    int i = 0;
    int j = 0;

    for (i; i < n1; i++)
        Left[i] = array[i + p];
    for (j; j < n2; j++)
        Right[j] = array[j + q + 1];

    i = j = 0;

    int k = p;

    while (i != n1 && j != n2)
    {
        if (Left[i] <= Right[j])
            array[k++] = Left[i++];
        else
            array[k++] = Right[j++];
    }

    while (i < n1)
        array[k++] = Left[i++];
    while (j < n2)
        array[k++] = Right[j++];

    free(Left);
    free(Right);

    count++;
    cout << "\nThe step" << setw(3) << count << ": ";
    printList(L);
}

void MergeSort(int array[], int p, int q, SqList &L)
{
    if (p < q)
    {
        int r = (p + q) / 2;
        MergeSort(array, p, r, L);
        MergeSort(array, r + 1, q, L);
        Merge(array, p, r, q, L);
    }
}

void merge_Sort(SqList &L)
{
    MergeSort(L.elem, 0, L.length, L);
}
