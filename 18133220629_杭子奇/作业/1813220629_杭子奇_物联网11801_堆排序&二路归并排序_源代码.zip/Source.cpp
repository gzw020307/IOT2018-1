#include "Function.h"

void functionChoose(void)
{
    SqList L;
    L.elem = new ElemType[16];

    int pos, choose;
    ElemType e;

    do
    {
        msg();
        cin >> choose;
        L.elem[0] = 0;
        L.elem[1] = 19;
        L.elem[2] = 38;
        L.elem[3] = 12;
        L.elem[4] = 40;
        L.elem[5] = 41;
        L.elem[6] = 39;
        L.elem[7] = 54;
        L.elem[8] = 76;
        L.elem[9] = 35;
        L.elem[10] = 47;
        L.elem[11] = 80;
        L.elem[12] = 14;
        L.elem[13] = 9;
        L.elem[14] = 44;
        L.elem[15] = 19;
        L.length = 15;
        switch (choose)
        {
        case 1:
            bin_Insertsort(L);
            cout << "\n\nFinished." << endl;
            break;

        case 2:
            bubble_Sort(L);
            cout << "\n\nFinished." << endl;
            break;

        case 3:
            heap_Sort(L);
            cout << "\n\nFinished." << endl;
            break;

        case 4:
            merge_Sort(L);
            cout << "\n\nFinished." << endl;
            break;

        case 5:
            cout << "\nThe list:" << endl;
            printList(L);
            cout << "\n\nFinished." << endl;
            break;

        case 0:
            delete L.elem;
            exit(1);
        }
    } while (choose != 0);
} // functionChoose

int main(void)
{
    functionChoose();
    return 0;
}