# include <stdio.h>
# include <stdlib.h>
# include <iostream>

# define TRUE 1
# define FALSE 0
# define OK 1
# define ERROR 0
# define OVERFLOW -1

//----------------------------------------
# define MAXQSIZE 100
# define ElemType int
//----------------------------------------

using namespace std;

typedef struct Node{
    ElemType *data;
    int front,rear;
} SqQueue;

int i, j;
ElemType *p, *q;