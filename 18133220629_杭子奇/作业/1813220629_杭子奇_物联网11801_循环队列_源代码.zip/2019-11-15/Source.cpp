# include "Function.h"

int main(void)
{
    char ch;
    ElemType e;
    int pos; 
    int choose;

    SqQueue Q;

    do{
        msg();
        cin >> choose; 
        switch (choose){
            case 1: 
                InitQueue(Q);
                cout << "How many elems?:";
                cin >> pos;
                for (i = 1; i <= pos; i++){
                    printf("Enter an elem(%d/%d):", i, pos);
                    cin >> e;
                    EnQueue(Q, e);
                }
                printQueue(Q);
                break;

            case 2:
                cout <<"Enter an elem: ";
                cin >> e;
                if(EnQueue(Q, e)) cout << "\nEnQ ueue Finished"<< endl;
                printQueue(Q);
                break;

            case 3:
                if(DeQueue(Q, e)) cout << "\nDeQueue Finished"<< endl;
                printQueue(Q);
                break;

            case 4:
                printQueue(Q);
                break;

            case 5:
                printTriangle();
                break;

            case 9:
                destroyQueue(Q);
                cout << "Detroy Finished." << endl;
                break;
        
            case 0:
                exit(1);    
        }

    }while(choose != 0);

    return 0;
}