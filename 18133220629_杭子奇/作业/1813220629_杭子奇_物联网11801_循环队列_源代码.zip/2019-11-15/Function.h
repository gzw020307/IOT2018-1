# include "Headerfile.h"

void msg(void){
    cout<< "-------------------------Menu-------------------------\n"
        << "*       1.(Initialize)Create a Queue                 *\n"
        << "*       2.Elem Enqueue                               *\n"
        << "*       3.Elem Dequeue                               *\n"
        << "*       4.Print the Queue                            *\n"
        << "*       5.Print Pascal's Triangle                    *\n"
        << "*       9.Destroy the Queue                          *\n"
        << "*       0.Exit.                                      *\n"
        << "-------------------------Menu-------------------------\n"
        << "Enter the function you want to choose(0-9):";
}

bool InitQueue(SqQueue &Q){
    // 创建队列
    Q.data = new ElemType[MAXQSIZE];
    if (!Q.data) exit(OVERFLOW);    // 申请内存空间失败
    Q.front = 0;
    Q.rear = 0;
    return OK;
}
bool EnQueue(SqQueue &Q,ElemType e){
    // 添加队列元素

    if((Q.rear+1)%MAXQSIZE==Q.front){
        cout << "\nTHE QUEUE IS FULL!" << endl;
        return FALSE;
    }
    Q.data[Q.rear]=e;
    Q.rear=(Q.rear+1)%MAXQSIZE;
    return OK;
}
int QueueLength(SqQueue &Q){
    // 返回队列长度

    return (Q.rear-Q.front+MAXQSIZE)%MAXQSIZE;
}
bool DeQueue(SqQueue &Q,ElemType &e){
    // 删除队列元素

    if(Q.front==Q.rear){
        cout<<"\nTHE QUEUE IS EMPTY"<<endl;
        return FALSE;
    }
    e=Q.data[Q.front];
    Q.front=(Q.front+1)%MAXQSIZE;
    return OK;
}
int getHead(SqQueue Q){
    // 得到队列头元素

    return Q.data[Q.front];
}
int QueueEmpty(SqQueue Q){
    // 判断队列是否为空

    if (Q.front==Q.rear)
        return OK;
    else
        return FALSE;
}
// --------------------------------------------------
//      杨辉三角部分
// --------------------------------------------------

void travelQueue(SqQueue &Q,int k){
    // 遍历输出

    int a = 0;
    int p = 0;
    for(int i = 1; i <= k; i++){
        p = a;
        DeQueue(Q, a);
        printf("%-4d", a);
        EnQueue(Q, a+p);
    }
    EnQueue(Q, a);
    cout << endl;
}

void printTriangle(void){
    int lines = 1;
    cout << "Enter the number of lines: ";
    cin >> lines;
    SqQueue S;
    InitQueue(S);
    EnQueue(S, 1);
    for(int i = 1; i <= lines; i++){
        for (j = 0; j < lines - i; j++) printf("  ");
        travelQueue(S, i);
    }
}
// 杨辉三角部分结束
// --------------------------------------------------

void printQueue(SqQueue Q){
    // 显示队列

    cout << "The Queue:" << endl;

    while((Q.front - Q.rear)%MAXQSIZE){
        cout << Q.data[Q.front%MAXQSIZE] << " ";
        Q.front++;
    }
    cout << "\n\nPrint Finished."<< endl;

}

void destroyQueue(SqQueue Q){
    // 销毁队列
    delete Q.data;
    Q.front = 0;
    Q.rear = 0;
}